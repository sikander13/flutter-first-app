package com.example.sikander

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
